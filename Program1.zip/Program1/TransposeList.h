//TransposeList Class, if list contains target node, swaps target with previous node

#ifndef TRANSPOSELIST_H_
#define TRANSPOSELIST_H_
#include "CDLinkedList.h"

class TransposeList : public CDLinkedList
{
public:
    virtual bool contains(int anEntry) override;
};
#endif